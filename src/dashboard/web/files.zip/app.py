import sys
import json
import re
from pathlib import Path
from datetime import datetime
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import mysql.connector

BASE_DIR = Path(__file__).parent

app = Flask(__name__, static_folder=str(BASE_DIR))
CORS(app)

def get_conn():
    return mysql.connector.connect(
        host="localhost", user="root", password="root", database="airbnb_douala"
    )

# ── Serve index.html ──────────────────────────────────────────────────────────
@app.route("/")
def index():
    return send_from_directory(str(BASE_DIR), "index.html")

# ── API: stats par quartier ───────────────────────────────────────────────────
@app.route("/api/stats")
def api_stats():
    try:
        conn = get_conn()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM stats_quartiers ORDER BY prix_moyen DESC")
        stats = cursor.fetchall()
        cursor.execute("SELECT * FROM stats_types ORDER BY total DESC")
        types = cursor.fetchall()
        cursor.execute("SELECT COUNT(*) as total, AVG(price_per_night) as avg_price, AVG(rating) as avg_rating FROM listings")
        summary = cursor.fetchone()
        conn.close()
        return jsonify({"stats_quartiers": stats, "stats_types": types, "summary": summary})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ── API: annonces filtrees ────────────────────────────────────────────────────
@app.route("/api/listings")
def api_listings():
    quartier = request.args.get("quartier", "all")
    type_bien = request.args.get("type", "all")
    prix_max = request.args.get("prix_max", "999999")
    source = request.args.get("source", "all")
    limit = int(request.args.get("limit", "200"))

    try:
        conn = get_conn()
        cursor = conn.cursor(dictionary=True)

        query = "SELECT * FROM listings WHERE 1=1"
        params = []

        if quartier != "all":
            query += " AND neighborhood = %s"
            params.append(quartier)
        if type_bien != "all":
            query += " AND type = %s"
            params.append(type_bien)
        if prix_max:
            query += " AND price_per_night <= %s"
            params.append(int(prix_max))
        if source != "all":
            query += " AND source = %s"
            params.append(source)

        query += " ORDER BY price_per_night DESC LIMIT %s"
        params.append(limit)

        cursor.execute(query, params)
        listings = cursor.fetchall()

        # Stats on filtered results
        cursor.execute(
            "SELECT COUNT(*) as total, AVG(price_per_night) as avg_price, AVG(rating) as avg_rating, "
            "AVG(occupancy_rate) as avg_occ FROM listings WHERE 1=1" +
            (" AND neighborhood=%s" if quartier != "all" else "") +
            (" AND type=%s" if type_bien != "all" else "") +
            (" AND price_per_night<=%s" if prix_max else "") +
            (" AND source=%s" if source != "all" else ""),
            [p for p in [quartier if quartier != "all" else None,
                         type_bien if type_bien != "all" else None,
                         int(prix_max) if prix_max else None,
                         source if source != "all" else None] if p is not None]
        )
        kpis = cursor.fetchone()
        conn.close()

        # Convert non-serializable types
        for l in listings:
            for k, v in l.items():
                if hasattr(v, "isoformat"):
                    l[k] = str(v)
                elif v is None:
                    l[k] = None

        return jsonify({"listings": listings, "kpis": kpis, "total": len(listings)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ── API: scraper par quartier ─────────────────────────────────────────────────
@app.route("/api/scrape", methods=["POST"])
def api_scrape():
    data = request.json or {}
    quartier = data.get("quartier", "Douala")

    try:
        import requests as req
        from bs4 import BeautifulSoup

        url = "https://www.airbnb.com/s/" + quartier + "--Cameroon/homes?flexible_trip_lengths%5B%5D=one_week&date_picker_type=flexible_dates"
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "Accept-Language": "fr-FR,fr;q=0.9"
        }

        r = req.get(url, headers=headers, timeout=15)
        soup = BeautifulSoup(r.text, "lxml")
        text = soup.get_text(" ", strip=True)

        # Extract basic stats from page
        listings_found = len(re.findall(r"/rooms/\d+", r.text))
        avg_price_match = re.findall(r"(\d{2,6})\s*€", text)
        prices = []
        for p in avg_price_match:
            try:
                val = float(p)
                if 5 < val < 2000:
                    prices.append(round(val * 655.957))
            except:
                pass

        result = {
            "quartier": quartier,
            "url_searched": url,
            "status_code": r.status_code,
            "listings_found_on_page": listings_found,
            "avg_price_xaf": round(sum(prices)/len(prices)) if prices else None,
            "scraped_at": datetime.now().isoformat()
        }

        return jsonify({"success": True, "result": result})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

if __name__ == "__main__":
    print("Starting Airbnb Douala API...")
    print("Open: http://localhost:5000")
    app.run(host="0.0.0.0", port=5000, debug=False)
